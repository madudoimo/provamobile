import { StyleSheet } from "react-native"

export const styles = StyleSheet.create({
    container : {
        flex: 1,
        backgroundColor: '#FFE5D9',
        paddingTop: 50
    },

    cabecalho : {
        backgroundColor: '#F4ACB7',
        height: 80,
        marginTop: -50,
    },

    foto : {
        height: 150, 
        width: 395,
        marginTop: -50,
        
        
    },

    foto2 : {
        height: 60, 
        width: 60,
        marginTop: 0,
        borderRadius: 50,
        marginLeft: 20,
        marginBottom: 10,
        
        
    },

    pesquisa: {
        height: 39,
        backgroundColor: '#e0e1dd',
        borderRadius: 45,
        color: '#000',
        padding: 12,
        fontSize: 16,
        marginTop: 19,
        marginRight: 40,
        marginLeft: 20,
        fontSize: 15
    },

    btn: {
        width: 39,
        height: 39,
        borderRadius: 55,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 355,
        marginTop: -38,

    },
     
    card: {
        backgroundColor: '#e5989b',
        marginTop: 30,
        height: 80,
        width: 350,
        marginLeft: 20,
        marginRight: 10,
        paddingTop: 10,
        borderRadius: 30,
        flexDirection: "row"
       
    },

    nome: {
        backgroundColor: '#f8f9fa',
        height: 29,
        width: 30,
        borderRadius: 15,
        flex: 0.9,
        marginLeft: 10,
        marginTop: 10,

    }

    
    
})
