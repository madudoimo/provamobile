import { View, Text, TextInput, TouchableOpacity, Image } from "react-native";
import { styles } from "../home/styles";
import { FontAwesome } from '@expo/vector-icons';


export default function Home(){
    function handleAluno(){
        console.log('ola')
    }

    return(
        <View style={styles.container}>
             <Image style={styles.foto} source={{uri: 'https://media.kasperskydaily.com/wp-content/uploads/sites/90/2015/12/06043557/hello-kitty-hacked-featured.jpg'}}/>

        <View style={styles.container}>
           
           <View style={styles.cabecalho}>

            <TextInput style={styles.pesquisa}/>
            <TouchableOpacity style={styles.btn}>
                <Text style={styles.btntxt}><FontAwesome name="search" size={24} color="black" /></Text>
            </TouchableOpacity>
           </View>

           <View style={styles.card}>
           <Image style={styles.foto2} source={{uri: 'https://www.cinconoticias.com/wp-content/uploads/La-verdadera-historia-de-Hello-Kitty.jpg'}}/>
           <TextInput style={styles.nome}/>
           </View>

           <View style={styles.card}>
           <Image style={styles.foto2} source={{uri: 'https://www.cinconoticias.com/wp-content/uploads/La-verdadera-historia-de-Hello-Kitty.jpg'}}/>
           <TextInput style={styles.nome}/>
           </View>

           <View style={styles.card}>
           <Image style={styles.foto2} source={{uri: 'https://www.cinconoticias.com/wp-content/uploads/La-verdadera-historia-de-Hello-Kitty.jpg'}}/>
           <TextInput style={styles.nome}/>
           </View>

           <View style={styles.card}>
           <Image style={styles.foto2} source={{uri: 'https://www.cinconoticias.com/wp-content/uploads/La-verdadera-historia-de-Hello-Kitty.jpg'}}/>
           <TextInput style={styles.nome}/>
           </View>

        </View>
        </View>
    )
}