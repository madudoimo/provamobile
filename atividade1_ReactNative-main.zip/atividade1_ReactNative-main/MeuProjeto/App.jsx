import Home from "../MeuProjeto/src/screens/home/index";

export default function App(){
  return(
    <Home />
  )
}